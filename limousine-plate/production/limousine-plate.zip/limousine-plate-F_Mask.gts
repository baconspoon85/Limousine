G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.5-1.fc39*
G04 #@! TF.CreationDate,2024-10-11T22:44:37-04:00*
G04 #@! TF.ProjectId,limousine-plate,6c696d6f-7573-4696-9e65-2d706c617465,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.5-1.fc39) date 2024-10-11 22:44:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
